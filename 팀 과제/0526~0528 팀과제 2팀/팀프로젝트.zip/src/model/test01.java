package model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class test01 {
	public static ArrayList<MusicVO> sample2() {

	      ArrayList<String> adatas = new ArrayList<String>();
	      ArrayList<String> tdatas = new ArrayList<String>();
	      ArrayList<MusicVO> mdatas= new ArrayList<MusicVO>();
	      int PK = 1;
	      
	      final String url = "https://www.melon.com/chart/";

	      Connection conn = Jsoup.connect(url);

	      Document doc = null;

	      try {
	         doc = conn.get();
	      } catch (IOException e) {
	         e.printStackTrace();
	      }

	      Elements elems = doc.select("div.ellipsis");

//	      String data = doc.select("div.ellipsis").text();


	      Iterator<Element> itr = elems.iterator();

//	      int rank = 1;
	      int i = 1;
	      while(itr.hasNext()) {

	         String str = itr.next().text();
	         //3줄 출력중

	         if(i % 3 == 1) {
	            tdatas.add(str);
	            //System.out.println(rank++ + "위    제목   "  + str);
	         }
	         if(i % 3 == 2) {
	            adatas.add(str);
	            //System.out.println("   가수   " + str);
	         }
	         if(i % 3 == 0) {
	            //System.out.println("   앨범   " + str);
	         }
	         i++;
	      }
	      
	      for(i = 0; i < tdatas.size(); i++) {
	         mdatas.add(new MusicVO(PK++,adatas.get(i),tdatas.get(i),0));
	      }
	      return mdatas;
	   }
}
