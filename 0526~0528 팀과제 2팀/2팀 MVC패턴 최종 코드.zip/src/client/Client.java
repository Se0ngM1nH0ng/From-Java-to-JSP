package client;

import ctrl.ProductCtrl;

public class Client {
	public static void main(String[] args) {

		ProductCtrl app=new ProductCtrl();
		app.startApp();
		
	}
}
